"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Gift, Search, ShoppingBag } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Sample gift ideas database
const giftIdeas = [
  {
    title: "World's Okayest Dad Mug",
    description: "For the dad who's not the best, not the worst, but somewhere comfortably in the middle.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["coffee", "humor", "drinking"],
    priceRange: "Under $25",
    occasions: ["Birthday", "Father's Day", "Christmas", "Easter", "New Year's", "Just Because"],
  },
  {
    title: "Tactical BBQ Apron",
    description: "Because grilling is serious business that requires serious gear.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["cooking", "bbq", "outdoors"],
    priceRange: "Under $50",
    occasions: ["Birthday", "Father's Day", "Christmas"],
  },
  {
    title: "Dad Joke Emergency Kit",
    description: "For when he runs out of eye-roll-inducing one-liners. Warning: May strengthen his dad joke game.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["humor", "reading"],
    priceRange: "Under $25",
    occasions: ["Birthday", "Father's Day", "Just Because", "Easter", "New Year's"],
  },
  {
    title: "Personalized Whiskey Decanter",
    description: "Make him feel fancy while he pretends to know the difference between whiskeys.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["drinking", "luxury"],
    priceRange: "Under $100",
    occasions: ["Birthday", "Christmas", "New Year's"],
  },
  {
    title: "Fishing Tackle Subscription Box",
    description: "New fishing gear every month, so he can continue to not catch anything in style.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["fishing", "outdoors"],
    priceRange: "Under $100",
    occasions: ["Birthday", "Christmas", "Just Because"],
  },
  {
    title: "Smart Grill Thermometer",
    description: "So he can obsessively check meat temperatures from his phone like a true dad.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["cooking", "bbq", "technology"],
    priceRange: "Under $100",
    occasions: ["Birthday", "Father's Day", "Christmas", "Easter"],
  },
  {
    title: "Noise Cancelling Headphones",
    description: "For when he wants to pretend he can't hear anyone asking him to do chores.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["music", "technology", "peace and quiet"],
    priceRange: "No Budget",
    occasions: ["Birthday", "Christmas"],
  },
  {
    title: "Multi-tool Pocket Knife",
    description: "So he can fix absolutely anything with one tool (or at least try to).",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["diy", "outdoors", "tools"],
    priceRange: "Under $50",
    occasions: ["Birthday", "Father's Day", "Christmas", "Just Because"],
  },
  {
    title: "Dad Bod Workout Kit",
    description: "Helps maintain that perfect dad bod physique he's worked so hard for.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["fitness", "humor"],
    priceRange: "Under $50",
    occasions: ["Birthday", "Just Because", "New Year's"],
  },
  {
    title: "Customized Golf Balls",
    description: "Personalized balls for a man who spends more time looking for them than hitting them.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["golf", "sports"],
    priceRange: "Under $25",
    occasions: ["Birthday", "Father's Day", "Christmas"],
  },
  {
    title: "Remote Control Finder",
    description: "Because the remote is always lost, even though 'nobody touched it'.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["technology", "tv"],
    priceRange: "Under $25",
    occasions: ["Birthday", "Christmas", "Just Because"],
  },
  {
    title: "Beard Grooming Kit",
    description: "Help him tame that face forest into something less frightening for the children.",
    image: "/placeholder.svg?height=200&width=200",
    interests: ["grooming", "style"],
    priceRange: "Under $50",
    occasions: ["Birthday", "Christmas", "New Year's"],
  },
]

// Rotating subheadlines
const subheadlines = [
  "Finding the perfect gift for the man who has everything (except maybe a sense of style)",
  "Because another tie just isn't going to cut it this year",
  "For the dad who says he doesn't want anything but secretly hopes you got him something cool",
  "Gift ideas that won't end up in his 'drawer of forgotten presents'",
  "Help your dad upgrade from 'World's Best Dad' mug to something he'll actually use",
]

// Rotating footer jokes
const footerJokes = [
  "We don't guarantee your dad will like these gifts, but we do guarantee he'll pretend to.",
  "If your dad says he doesn't like his gift, remind him you inherited your taste from him.",
  "Our gifts are dad-tested, child-approved, and mom-tolerated.",
  "Perfect for the man who taught you everything you know (except how to pick good gifts).",
  "Because the best gift is your love and appreciation... but these are pretty good too.",
]

export default function Home() {
  const [occasion, setOccasion] = useState<string>("")
  const [interests, setInterests] = useState<string>("")
  const [budget, setBudget] = useState<string>("")
  const [showResults, setShowResults] = useState(false)
  const [giftResults, setGiftResults] = useState<any[]>([])

  // Select random subheadline and footer joke on component mount
  const [randomSubheadline] = useState(() => subheadlines[Math.floor(Math.random() * subheadlines.length)])
  const [randomFooterJoke] = useState(() => footerJokes[Math.floor(Math.random() * footerJokes.length)])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Filter gift ideas based on form inputs
    let results = [...giftIdeas]

    if (occasion) {
      results = results.filter((gift) => gift.occasions.includes(occasion))
    }

    if (interests) {
      const interestTerms = interests
        .toLowerCase()
        .split(/,|\s+/)
        .filter((term) => term.length > 2)
      if (interestTerms.length > 0) {
        results = results.filter((gift) =>
          interestTerms.some((term) => gift.interests.some((interest) => interest.toLowerCase().includes(term))),
        )
      }
    }

    if (budget) {
      // For "No Budget", we include all items
      if (budget !== "No Budget") {
        results = results.filter((gift) => {
          // For "Under $X", include all gifts with lower price ranges too
          if (budget === "Under $100") {
            return ["Under $25", "Under $50", "Under $100"].includes(gift.priceRange)
          } else if (budget === "Under $50") {
            return ["Under $25", "Under $50"].includes(gift.priceRange)
          } else {
            return gift.priceRange === budget
          }
        })
      }
    }

    // If we have too few results, add some random ones that match at least the budget
    if (results.length < 3 && budget) {
      const additionalItems = giftIdeas
        .filter((gift) => !results.includes(gift))
        .filter((gift) => {
          if (budget === "No Budget") return true
          if (budget === "Under $100") {
            return ["Under $25", "Under $50", "Under $100"].includes(gift.priceRange)
          } else if (budget === "Under $50") {
            return ["Under $25", "Under $50"].includes(gift.priceRange)
          } else {
            return gift.priceRange === budget
          }
        })
        .sort(() => 0.5 - Math.random())
        .slice(0, 3 - results.length)

      results = [...results, ...additionalItems]
    }

    // If still not enough results, just add random ones
    if (results.length < 3) {
      const randomItems = giftIdeas
        .filter((gift) => !results.includes(gift))
        .sort(() => 0.5 - Math.random())
        .slice(0, 3 - results.length)

      results = [...results, ...randomItems]
    }

    // Shuffle the results for variety
    results = results.sort(() => 0.5 - Math.random()).slice(0, 6)

    setGiftResults(results)
    setShowResults(true)
  }

  const getAmazonSearchUrl = (title: string) => {
    return `https://www.amazon.com/s?k=${encodeURIComponent(title)}`
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-sky-50 to-blue-100 via-amber-50">
      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-sky-600 mb-4">What Should I Get My Dad?</h1>
          <p className="text-xl md:text-2xl text-gray-700 max-w-2xl mx-auto">{randomSubheadline}</p>
        </div>

        {/* Form Section */}
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md p-6 mb-12 border border-amber-100">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="occasion">Occasion</Label>
                <Select value={occasion} onValueChange={setOccasion}>
                  <SelectTrigger id="occasion">
                    <SelectValue placeholder="Select an occasion" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Birthday">Birthday</SelectItem>
                    <SelectItem value="Father's Day">Father's Day</SelectItem>
                    <SelectItem value="Christmas">Christmas</SelectItem>
                    <SelectItem value="Easter">Easter</SelectItem>
                    <SelectItem value="New Year's">New Year's</SelectItem>
                    <SelectItem value="Just Because">Just Because</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="budget">Budget</Label>
                <Select value={budget} onValueChange={setBudget}>
                  <SelectTrigger id="budget">
                    <SelectValue placeholder="Select your budget" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Under $25">Under $25</SelectItem>
                    <SelectItem value="Under $50">Under $50</SelectItem>
                    <SelectItem value="Under $100">Under $100</SelectItem>
                    <SelectItem value="No Budget">No Budget</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="interests">Dad's Interests (separate with commas)</Label>
              <Input
                id="interests"
                placeholder="e.g., golf, grilling, fishing, technology"
                value={interests}
                onChange={(e) => setInterests(e.target.value)}
              />
            </div>

            <Button type="submit" className="w-full bg-sky-500 hover:bg-orange-500">
              <Search className="mr-2 h-4 w-4" /> Find My Gift
            </Button>
          </form>
        </div>

        {/* Results Section */}
        {showResults && (
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">Perfect Gifts For Your Dad</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {giftResults.map((gift, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow border-amber-100">
                  <CardHeader className="p-0">
                    <div className="relative h-48 w-full">
                      <Image src={gift.image || "/placeholder.svg"} alt={gift.title} fill className="object-cover" />
                    </div>
                  </CardHeader>
                  <CardContent className="p-6">
                    <CardTitle className="text-xl mb-2">{gift.title}</CardTitle>
                    <p className="text-gray-600">{gift.description}</p>
                    <div className="mt-2 flex items-center text-sm text-gray-500">
                      <ShoppingBag className="h-4 w-4 mr-1" />
                      <span>{gift.priceRange}</span>
                    </div>
                  </CardContent>
                  <CardFooter className="p-6 pt-0">
                    <Button
                      className="w-full bg-sky-500 hover:bg-orange-500"
                      onClick={() => window.open(getAmazonSearchUrl(gift.title), "_blank")}
                    >
                      <Gift className="mr-2 h-4 w-4" /> View Gift
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <footer className="text-center text-gray-600 mt-12">
          <p>© {new Date().getFullYear()} What Should I Get My Dad? | The ultimate dad gift finder</p>
          <p className="text-sm mt-2">{randomFooterJoke}</p>
        </footer>
      </div>
    </main>
  )
}
